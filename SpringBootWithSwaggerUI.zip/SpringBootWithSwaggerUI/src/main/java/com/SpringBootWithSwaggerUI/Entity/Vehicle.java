package com.SpringBootWithSwaggerUI.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="VechicleDetails")
public class Vehicle {


	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Vehicle_id")
	private int id;
	
	@Column(name="Vehicle_Brand")
	private String brand;
	
	@Column(name="Vehicle_Color")
	private String color;

	
}
