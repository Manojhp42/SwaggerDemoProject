package com.SpringBootWithSwaggerUI.Entity;
import java.util.Date;
public class ErrorMessage {
  private int publicerrorCode;
  private String errorMessage;
  private Date date;
  
  
  public int getPublicerrorCode() {
	return publicerrorCode;
}


public void setPublicerrorCode(int publicerrorCode) {
	this.publicerrorCode = publicerrorCode;
}


public String getErrorMessage() {
	return errorMessage;
}


public void setErrorMessage(String errorMessage) {
	this.errorMessage = errorMessage;
}


public Date getDate() {
	return date;
}


public void setDate(Date date) {
	this.date = date;
}



public ErrorMessage() {
	super();
}




public ErrorMessage(int publicerrorCode, String errorMessage, Date date) {
	super();
	this.publicerrorCode = publicerrorCode;
	this.errorMessage = errorMessage;
	this.date = date;
}


@Override
public String toString() {
	return "ErrorMessage [publicerrorCode=" + publicerrorCode + ", errorMessage=" + errorMessage + ", date=" + date
			+ "]";
}
  
}
