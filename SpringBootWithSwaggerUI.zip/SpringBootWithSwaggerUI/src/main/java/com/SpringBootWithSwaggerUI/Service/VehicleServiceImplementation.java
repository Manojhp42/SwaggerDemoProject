package com.SpringBootWithSwaggerUI.Service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootWithSwaggerUI.Entity.Vehicle;
import com.SpringBootWithSwaggerUI.GlobalExceptionHandling.FieldIsEmptyException;
import com.SpringBootWithSwaggerUI.GlobalExceptionHandling.ResponseNotFoundException;
import com.SpringBootWithSwaggerUI.Repository.VehicleRepository;


@Service
public class VehicleServiceImplementation implements VehicleService 
{

	
	@Autowired
	 private VehicleRepository vehicleRepository;
	
	@Override
	public Vehicle saveVehicle(Vehicle vehicle) {
		
		
		if(!vehicle.getBrand().isEmpty() && !vehicle.getColor().isEmpty())
		{
		return vehicleRepository.save(vehicle);
		}
		else
		{
			throw  new FieldIsEmptyException();
		}
		
	}

	@Override
	public List<Vehicle> saveAllVehicle(List<Vehicle> listvehicle) {
		
		return vehicleRepository.saveAll(listvehicle) ;
	}

	@Override
	public Vehicle getVehicleById(Integer id) throws ResponseNotFoundException    {
    try
	{
		 Vehicle v=vehicleRepository.findById(id).get();
		 return v;
	}
	catch(Exception e)
	{
	  throw new ResponseNotFoundException("Not found Tutorial with id = " + id);	
	}
	}

	@Override
	public List<Vehicle> getAllVehicle() {
		
		return vehicleRepository.findAll();
	}

    @Override
	public String deleteVehicleById(Integer id) {
	
		 vehicleRepository.deleteById(id);
		 return "deleted";
	}

	@Override
	public String deleteAllVehicle() {
	
		vehicleRepository.deleteAll();;
		return "AllValueDelete";
	}

	@Override
	public Vehicle updateVehicleById(Integer id,Vehicle v1) {
		
		Vehicle v=vehicleRepository.findById(id).get();
		v.setBrand(v1.getBrand());
		v.setColor(v1.getColor());
		return  vehicleRepository.save(v);
	}

	
	

	

}
