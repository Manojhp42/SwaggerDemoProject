package com.SpringBootWithSwaggerUI.Service;

import java.util.List;

import com.SpringBootWithSwaggerUI.Entity.Vehicle;
import com.SpringBootWithSwaggerUI.GlobalExceptionHandling.ResponseNotFoundException;

public interface VehicleService {

	Vehicle saveVehicle(Vehicle vehicle	);
	List<Vehicle> saveAllVehicle(List<Vehicle> listvehicle);
	Vehicle getVehicleById(Integer id) throws ResponseNotFoundException ;
	List<Vehicle> getAllVehicle();
	String deleteVehicleById(Integer id);
     String deleteAllVehicle();
	Vehicle updateVehicleById(Integer id,Vehicle v1);

	
 		
}
