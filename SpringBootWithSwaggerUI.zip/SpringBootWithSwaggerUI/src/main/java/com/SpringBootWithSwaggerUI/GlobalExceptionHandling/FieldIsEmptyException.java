package com.SpringBootWithSwaggerUI.GlobalExceptionHandling;

public class FieldIsEmptyException extends RuntimeException {
    
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FieldIsEmptyException() 
	{
		super();
	}

	
}
