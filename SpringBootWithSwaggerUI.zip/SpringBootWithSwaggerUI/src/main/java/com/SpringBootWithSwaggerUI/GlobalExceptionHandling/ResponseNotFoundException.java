package com.SpringBootWithSwaggerUI.GlobalExceptionHandling;

public class ResponseNotFoundException extends Exception {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResponseNotFoundException(String string)
	{
		super(string);
	}
}
