package com.SpringBootWithSwaggerUI.GlobalExceptionHandling;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.SpringBootWithSwaggerUI.Entity.ErrorMessage;

@RestControllerAdvice
public class AllControllerExceptionHandler {

	@ExceptionHandler(FieldIsEmptyException.class)
	public ResponseEntity<ErrorMessage> handlingException()
	{
		ErrorMessage em=new ErrorMessage(404,"field not found",new Date());
		return new ResponseEntity<ErrorMessage>(em, HttpStatus.BAD_REQUEST);
		
	}
	
	
	@ExceptionHandler(ResponseNotFoundException.class)
	public ResponseEntity<ErrorMessage> handlingException1(ResponseNotFoundException re)
	{
		ErrorMessage em=new ErrorMessage(404,re.getMessage(),new Date());
		return new ResponseEntity<ErrorMessage>(em, HttpStatus.NOT_FOUND);
		
	}
	
}
